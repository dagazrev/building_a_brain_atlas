There's a skull stripped atlas and a complete mean intensities atlas.

for the code to run, it assumes the py files are in the same folder as the data, that
should be in a folder structure as follows:

training
	training-images
	training-labels
	training-mask